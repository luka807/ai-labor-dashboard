# Leadership Now Project — Design System

A design system for the **Leadership Now Project (LNP)**, a membership organization of business and thought leaders committed to protecting democracy as the foundation for a thriving economy and political stability. Founded in 2017 by Harvard Business School alumni, LNP has members across 30+ states and chapters in nine.

LNP works across three modes — **Inform, Influence, Invest** — running 35+ events a year, shaping policy, and mobilizing $30M+ per cycle behind pragmatic centrist candidates and organizations.

The brand has to read as **credible, business-grade, and nonpartisan** — closer to McKinsey or the Aspen Institute than to a campaign or advocacy group. The visual system leans on a single gold accent, deep navy, generous whitespace, and authoritative typography.

---

## Surfaces this system covers

LNP communicates through three primary surfaces:

1. **Slide decks** — the dominant medium. Member briefings, investor strategy meetings, summit content, partner pitches. Built in Google Slides / PowerPoint, 16:9. Title slides + content slides + market-map / segmentation grids. (See `ui_kits/slides/`.)
2. **Marketing website** — `leadershipnowproject.org` (WordPress). Mission, team, insights, candidates, membership. Authoritative, photo-led editorial layouts. (See `ui_kits/website/`.)
3. **Standalone microsites** — e.g. `businessplan.leadershipnowproject.org`, a Next.js publication site for the *Business Plan for America* policy series. Long-form, multi-pillar editorial.
4. **Member portal** — `members.leadershipnowproject.org` (private, referral-only community). Not directly designed in this kit — flagged for the user.

---

## Sources

Materials reviewed to build this system:

- **Logo pack** (uploaded zip — see `assets/logos/`): full + mark + reverse + favicon, plus four themed icon glyphs (tech, money, elections, voting).
- **Slide decks** (`source_decks/` — references):
  - *Business Plan for America — "Phase 2 Rollout Plan" Executive Deck (May 2026)* — 41-slide activation plan; **the canonical layout reference for the slide kit** (extracted ✔)
  - *2026 Annual Summit Slides [WIP]* — full summit deck (too large to embed)
  - *2026 Election Risks: What Business Needs to Know* — member briefing (too large to embed)
  - *Centrist Constituency Fund: Update (November 2025)* — investor update (extracted ✔)
  - *LNP Business Plan — May 12 Investor Strategy Meeting* (too large to embed)
- **Public web**: `leadershipnowproject.org/home`, `/our-principles`, `/priorities`, `/membership`, and `businessplan.leadershipnowproject.org/executive-summary`.

> **Note to reviewer:** three of the four pptx files exceeded the 30 MiB upload cap and could not be fully extracted in this environment. Visual conventions were drawn from the Centrist Constituency Fund deck (fully extracted) plus the public web. If you can re-share the larger decks (or screenshots of representative slides), I can tighten the slide-kit accordingly.

---

## Index

```
README.md                  ← you are here
SKILL.md                   ← Agent Skills entrypoint (Claude Code compatible)
colors_and_type.css        ← CSS custom properties: colors, type, spacing, radii, motion

assets/
  logos/                   ← LN mark + full wordmark, on light & dark
  icons/                   ← Themed glyph icons (tech, money, elections, voting)
  imagery/                 ← Brand photography (Liberty duotone, dot-pattern bg)

ui_kits/
  slides/                  ← 16:9 deck (BP4A Phase 2 reference) — title, section
                             divider, agenda, function cards, KPI stat strip,
                             archetype cards, timeline table + flag, activation
                             cycle, consolidated matrix, closing
  website/                 ← leadershipnowproject.org — nav, hero, announcement,
                             pillars, mandate (dark), join us, newsletter, footer
  llm-pricing-dashboard/   ← non-LNP product styled in the LNP brand; a worked
                             example of the system applied to a dense data app:
                             sortable table, live cost calculator, log-scale
                             scatter, step-line price history, detail drawer
  /* business_plan/ kit not yet built — see CAVEATS in chat */

preview/                   ← Design-system cards (rendered in the Design System tab)
source_decks/              ← Reference materials (decks, theme XML, extracted media)
```

---

## CONTENT FUNDAMENTALS

How LNP writes. Every choice here is calibrated for business-leader audiences — board members, CEOs, institutional investors, senior policy hands.

### Voice & posture

- **Authoritative, plain, pragmatic.** Reads like a strategy memo, not advocacy copy. No exhortation, no slogans-as-sentences. Closer to *The Economist* than to a campaign.
- **First-person plural ("we") for the organization** — never "I", rarely "you". The reader is a peer being invited into a coordinated effort, not a target being persuaded.
  - ✅ "We convene leading experts to identify policy solutions…"
  - ✅ "Leadership Now is a membership organization of business leaders…"
  - ❌ "You can help us protect democracy."
- **Nonpartisan by construction.** Always paired language: *moderate, pragmatic, centrist, principled*. Critiques are about systems (elections, rule of law, institutional trust), not opponents. The word *bipartisan* is used sparingly; *nonpartisan* and *centrist* are preferred.
- **Action-verb framing.** The Three Modes are the spine: **Inform. Influence. Invest.** Headlines almost always lead with verbs: *Defend. Build. Restore. Launch. Respond. Develop.*

### Casing & rhythm

- **ALL-CAPS eyebrows** above titles, set in Montserrat 700 with letter-spacing (`.14em`). e.g. `THE WORK AHEAD`, `HOW WE'RE DOING IT`, `2026 MANDATE`. This is the brand's strongest typographic tic.
- **Title Case for slide titles and page H1s.** "Meeting the Moment", "The Business Plan For America", "Centrist Constituency Market Map".
- **Sentence case for body, leads, and most subheads.** Avoid Title Case in paragraphs.
- **Em-dashes — used liberally** for editorial cadence. Single space on each side is the deck convention; the web treats them per typographic norms.
- **Numbered priorities** (`01`, `02`, …) with leading zero — pulled directly from the Business Plan microsite and the Annual Summit deck. This is the canonical way to introduce a sequence. The BP4A deck extends this to **oversized ghost numerals** on section dividers and **mono section indices** (`01 / 06`).
- **Amber “Flag” callouts** (`⚠ FLAG`) flag open questions, calendar conflicts, and unresolved decisions inline — a warm-gold wash with a gold left-rule and brown text. A signature device of the BP4A deck for surfacing what still needs to be locked.

### Specific phrases used as terms of art

- *meeting the moment*
- *what comes next* / *America's next chapter*
- *principled leadership* and *healthy conflict*
- *durable, replicable ecosystem*
- *catalytic grants*
- *credible governing agenda*
- *politically homeless* (re: moderate voters)
- *Inform / Influence / Invest* — capitalized when used as the three pillars

### What to avoid

- Exclamation points. (Never.)
- Emoji. (Never — the brand is corporate-governance grade.)
- "Stakeholders", "synergies", "leverage" used as a verb, and other consultant tells.
- Loaded political language ("MAGA", specific candidate names, party-line phrases).
- Cute headlines, puns, alliteration-as-style. Headlines are declarative.

### Reference quotes (verbatim from sources, for ear-tuning)

> "Leadership Now is a membership organization of business leaders who believe that a strong democracy is key to a thriving economy and political stability."

> "A pragmatic agenda for America's next chapter — to boost economic competitiveness, enable broad-based prosperity, and build a government that works and earns trust."

> "Build a coordinated ecosystem that strengthens the political center through shared learning, aligned tools, and cross-group collaboration."

> "Members invest $30M+ per cycle in aligned candidates and organizations."

---

## VISUAL FOUNDATIONS

### Color

A deliberately restricted palette — **one signature gold, a deep navy family, and a wide neutral ramp.** Color is used sparingly; the brand reads as confident in its restraint.

- **Gold `#FFB739`** — the *only* saturated brand color. Used as: (1) the logo mark background, (2) a short underline rule beneath title-slide titles, (3) eyebrow / micro-accent. Never used for large fills or full backgrounds. Never used for body text.
- **Navy family** — `#003D4D` (deck navy), `#092B5F` (deepest navy), `#3260A9` (lighter accent / link). These appear in deck heads and in photographic duotones.
- **Ink `#1F2024`** — the actual text color in the logo wordmark and on the website. Slightly warmer than pure black.
- **Neutrals** — white, off-white paper `#F7F6F2`, and a 50→900 gray ramp.

No gradients. No semi-transparent overlays as primary surfaces. No purple, no teal, no magenta — anything off-palette will look immediately wrong.

### Typography

- **Display + headings: Proxima Nova** — 700/800 weights handle titles and headings; ALL-CAPS eyebrows use 700 with `.14em` tracking. The brand uses a single typeface family across display and body.
- **Body: Proxima Nova** — clean geometric-humanist sans, self-hosted from `fonts/`. Full family wired: **300 Light · 400 Regular · 500 Medium · 600 Semibold · 700 Bold · 800 Extrabold**, each with matching italics.
- **Editorial accent: Source Serif 4** — used sparingly for pull-quotes and the occasional editorial headline on the Business Plan microsite. Italic by default for quotes.

> Proxima Nova is fully self-hosted from `fonts/` (6 weights, upright + italic). **Source Serif 4** is loaded from Google Fonts (free, open-licensed).

### Spacing & layout

- **4px base spacing scale** (`--s-1` … `--s-32`) — generous, never cramped. Section padding on the web is typically `--s-20` (80px) top/bottom; on slides it's `--s-12` to `--s-16` from the margins.
- **Layouts are gridded and column-driven**, not freeform. The Business Plan site uses a 12-column grid with strong vertical rhythm. Decks use a fixed 1920×1080 with a ~80px left margin.
- **Generous whitespace.** When in doubt, more air.

### Backgrounds

- **White, primarily.** The default surface for both decks and web is plain white.
- **Subtle dot pattern** — a light gray dot grid on white is used as a section-divider / breather background on certain slides. (See `assets/imagery/dot-pattern-bg.png`.)
- **Paper `#F7F6F2`** — used as a warm off-white for alternating sections on the web.
- **Deep navy** (`#092B5F`) used full-bleed only for occasional hero or closing slides; never for body content.
- **No animated backgrounds. No mesh gradients. No noise textures.**

### Imagery

- **Photography is the primary image system.** No illustrations.
- **Duotone treatment for hero photography** — the signature look is a deep-blue duotone of monumental Americana subjects (Statue of Liberty, Capitol, Lincoln Memorial). Highlights desaturated to white, shadows pushed to navy `#003D4D` / `#092B5F`. Cool and slightly desaturated — never warm, never grainy. (See `assets/imagery/liberty-front.png`, `liberty-back.png`.)
- **Editorial color photography** elsewhere — landscape, architecture, civic scenes. Wide, cinematic crops. No people-portraits used as decoration; portraits only when they belong (team page, candidate cards).
- **No stock-photo handshakes, no flag-clichés, no AI-generated imagery.**

### Borders, cards, elevation

- **Borders over shadows.** The system prefers 1px hairline borders (`--color-border`, `--color-border-strong`) on cards. Drop-shadows are reserved for floating UI (menus, modals).
- **Sharp corners.** Default radius is `0` for buttons and section blocks, `2px` for inputs, `4px–8px` for large cards. No fully-rounded surfaces.
- **The iconic gold rule** — a short, thick gold line (~72px × 6px) lives under most title labels and section heads. This is the brand's most recognizable graphic device. Use `.lnp-rule-gold` or `<hr class="lnp-rule-gold">`.
- **No inner shadows. No glassmorphism. No frosted blur backgrounds.**

### Motion

- **Restrained, functional, no ornament.** The site has essentially no decorative motion; decks are static.
- Use `--ease-standard` (`cubic-bezier(0.2,0.7,0.2,1)`) at `--dur-base` (200ms) for interactive transitions — hover, focus, menu open.
- **No bounces, no springs, no spring-bouncy easing.** No autoplaying carousels or sliders.

### Hover / press states

- **Hover** = subtle darkening. Gold → `--lnp-gold-600`. Link text shifts from `--lnp-navy-mid` to `--lnp-navy-deep` and gains an underline.
- **Press** = the same darker color, no shrink or scale transform. The brand does not use the "press to shrink" mobile idiom.
- **Focus** = 2px outline in `--lnp-navy-mid`, `--s-1` offset. Always visible — accessibility matters for an institutional brand.
- Buttons never change shape on interaction.

### Transparency & blur

- **Used very sparingly.** The only acceptable use is a subtle gradient protection layer behind text overlaying photography. No blurred panels, no frosted nav bars, no semi-transparent floating cards.

### Layout rules

- **Fixed top nav** on the marketing site, opaque white, hairline bottom border. No transparent / blurred nav.
- **Slides** keep the LN mark anchored bottom-left at all times.
- **The gold underline rule sits immediately below the title**, left-aligned to the title. It's the visual anchor for the entire title block.

### What to never do

Avoid these — they'd break the brand instantly:
- Bluish-purple gradients
- Rounded "pill" cards with colored left borders
- Emoji or unicode-symbol icons used decoratively
- AI-generated illustrations
- More than one accent color on a single surface
- Italics in body copy (reserve italics for editorial quotes)
- Stock "diverse team huddled around a laptop" photography

---

## ICONOGRAPHY

LNP uses a **very limited, hand-curated icon set** — not a comprehensive system icon font. There are essentially two icon registers:

### 1. Brand themed glyphs (`assets/icons/`)

Four custom solid-gold pictograms ship in the brand pack:

| File | Subject | Used for |
|---|---|---|
| `lnp-icon-tech.png` | Lightbulb with circuit-board filament | Innovation, technology pillars |
| `lnp-icon-money.png` | Stacked banknotes with dollar sign | Investment, fiscal strength |
| `lnp-icon-elections.png` | Ballot box | Election security, voting access |
| `lnp-icon-voting.png` | Two raised hands | Civic engagement, mobilization |

These are **solid gold** (`#FFB739`), filled, with a chunky stroke style. They function as section-marker iconography in decks, not as UI icons. Don't use them at small sizes (<48px) or in dense interfaces. PNGs ship with transparent backgrounds.

### 2. UI icons

The brand does **not have its own UI icon font or SVG set.** For functional UI (chevrons, search, menu, share, etc.) this kit recommends **Lucide** — a free, open, MIT-licensed icon library with a clean 1.5px stroke that complements Montserrat + Inter without overpowering. Load via CDN:

```html
<script src="https://unpkg.com/lucide@latest"></script>
<script>lucide.createIcons();</script>
```

Use Lucide at `--color-fg` (ink) or `--color-fg-muted`; stroke-width 1.75–2px. **Don't tint UI icons gold** — gold is reserved for brand glyphs and the underline rule.

> **Substitution flag:** Lucide is a substitution, not what LNP currently uses on their WordPress site (which relies on theme defaults / one-off SVGs). If the team has a preferred icon set, swap it in `colors_and_type.css` and update the kits.

### 3. Emoji & unicode

**Never.** Emoji break the institutional voice. Unicode symbols (▸ ◆ ●) are acceptable as bullet markers in dense slide layouts when a real icon would be too heavy, but use sparingly.

---

## Quick start

```html
<link rel="stylesheet" href="colors_and_type.css">

<header>
  <img src="assets/logos/lnp-logo-yellow-black.png" alt="Leadership Now Project" height="40">
</header>

<main>
  <p class="lnp-eyebrow">The Work Ahead</p>
  <h1 class="lnp-h1">Meeting the Moment</h1>
  <hr class="lnp-rule-gold">
  <p class="lnp-lead">Leadership Now is a membership organization of business leaders who believe that a strong democracy is key to a thriving economy and political stability.</p>
</main>
```

---

## Open questions for the team

1. **Proxima Nova webfont license** — if available, please share so we can drop the substitution.
2. **Larger decks (Summit, Election Risks, Business Plan investor)** — please re-share or provide PDFs / screenshots so the slide kit can reflect their layouts.
3. **Member portal styling** — do you want this kit to cover `members.leadershipnowproject.org` too? It looked auxiliary (vendor-templated) but I can fold it in if it's now in scope.
4. **Iconography** — happy with Lucide as the UI-icon stand-in, or do you have a preferred set?
