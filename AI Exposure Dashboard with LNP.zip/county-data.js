// County data loader. PLACEHOLDER: values are generated deterministically per county
// to match the ranges in the design spec. Replace load() with the real joined
// Brookings + Upjohn + BLS QCEW data, keeping the same record shape.
(function () {
  const ST = {'01':['AL','Alabama'],'02':['AK','Alaska'],'04':['AZ','Arizona'],'05':['AR','Arkansas'],'06':['CA','California'],'08':['CO','Colorado'],'09':['CT','Connecticut'],'10':['DE','Delaware'],'11':['DC','District of Columbia'],'12':['FL','Florida'],'13':['GA','Georgia'],'15':['HI','Hawaii'],'16':['ID','Idaho'],'17':['IL','Illinois'],'18':['IN','Indiana'],'19':['IA','Iowa'],'20':['KS','Kansas'],'21':['KY','Kentucky'],'22':['LA','Louisiana'],'23':['ME','Maine'],'24':['MD','Maryland'],'25':['MA','Massachusetts'],'26':['MI','Michigan'],'27':['MN','Minnesota'],'28':['MS','Mississippi'],'29':['MO','Missouri'],'30':['MT','Montana'],'31':['NE','Nebraska'],'32':['NV','Nevada'],'33':['NH','New Hampshire'],'34':['NJ','New Jersey'],'35':['NM','New Mexico'],'36':['NY','New York'],'37':['NC','North Carolina'],'38':['ND','North Dakota'],'39':['OH','Ohio'],'40':['OK','Oklahoma'],'41':['OR','Oregon'],'42':['PA','Pennsylvania'],'44':['RI','Rhode Island'],'45':['SC','South Carolina'],'46':['SD','South Dakota'],'47':['TN','Tennessee'],'48':['TX','Texas'],'49':['UT','Utah'],'50':['VT','Vermont'],'51':['VA','Virginia'],'53':['WA','Washington'],'54':['WV','West Virginia'],'55':['WI','Wisconsin'],'56':['WY','Wyoming']};

  const SECTORS = [
    {k:'fed', label:'Federal government (civilian)', gov:true},
    {k:'stg', label:'State government', gov:true},
    {k:'locg', label:'Local government (incl. public schools)', gov:true},
    {k:'ag', label:'Agriculture, forestry & mining'},
    {k:'con', label:'Construction'},
    {k:'mfg', label:'Manufacturing'},
    {k:'ttu', label:'Trade, transportation & utilities'},
    {k:'inf', label:'Information'},
    {k:'fin', label:'Finance, insurance & real estate'},
    {k:'pbs', label:'Professional & business services'},
    {k:'edh', label:'Private education & health care'},
    {k:'lh', label:'Leisure & hospitality'},
    {k:'oth', label:'Other services'},
    {k:'nd', label:'Not disclosed by BLS', nd:true}
  ];
  const PRIVATE = ['ag','con','mfg','ttu','inf','fin','pbs','edh','lh','oth'];

  const POP = {'06037':10105722,'17031':5275541,'48201':4731145,'04013':4420568,'06073':3298634,'06059':3186989,'36047':2736074,'12086':2701767,'48113':2613539,'36081':2405464,'32003':2265461,'53033':2269675,'06065':2418185,'48439':2110640,'06071':2181654,'48029':2009324,'26163':1793561,'36061':1694251,'42101':1603797,'25017':1632002,'06085':1936259,'06075':873965,'02020':291247,'11001':689545,'48301':74,'15005':82};
  const EXP = {'06085':0.467,'06075':0.441,'11001':0.412,'53033':0.402,'36061':0.398};
  const NO_EXP = {'02261':1,'15005':1}, NO_EMP = {'48301':1}, NO_IND = {'15005':1,'02068':1};

  function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
  function rng(seed){let a=seed;return function(){a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
  function gauss(r){let u=0;while(!u)u=r();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*r());}
  const bump=(x,y,cx,cy,rad)=>Math.exp(-((x-cx)**2+(y-cy)**2)/(2*rad*rad));
  const field=(x,y,p)=>Math.sin(x/53+p)*Math.cos(y/41-p*1.7)+0.6*Math.sin((x+y)/29+p*2.3)+0.4*Math.cos((x-y)/71+p);
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

  function displayName(base, id, abbr){
    if (id === '11001') return 'District of Columbia';
    let suf = ' County';
    if (abbr === 'LA') suf = ' Parish';
    else if (abbr === 'AK') suf = /Census Area|Borough|Municipality/.test(base) ? '' : ' Borough';
    else if (abbr === 'VA' && +id.slice(2) >= 500) suf = ' city';
    else if (/ city$| City$/.test(base)) suf = '';
    return base + suf + ', ' + abbr;
  }

  async function load(){
    const topo = await fetch('https://cdn.jsdelivr.net/npm/us-atlas@3/counties-albers-10m.json').then(r=>r.json());
    const path = d3.geoPath();
    const features = topojson.feature(topo, topo.objects.counties).features.filter(f => ST[String(f.id).slice(0,2)]);
    const raw = features.map(f => {
      const id = String(f.id), r = rng(hash(id));
      const [x,y] = path.centroid(f), area = Math.max(path.area(f), 2);
      const lp = Math.log(26000) + 0.75*Math.log(110/area) + 0.95*gauss(r) + 0.5*bump(x,y,860,200,140) + 0.15*field(x,y,1.3);
      return {f, id, r, x, y, pop: Math.exp(lp)};
    });
    let fixed = 0, free = 0;
    raw.forEach(o => POP[o.id] ? fixed += POP[o.id] : free += o.pop);
    const scale = (334900000 - fixed) / free;
    const counties = raw.map(o => {
      const {f, id, r, x, y} = o, st = id.slice(0,2), [abbr, stName] = ST[st];
      const pop = POP[id] || Math.round(clamp(o.pop*scale, 300, 1900000));
      const u = clamp((Math.log(pop) - 9.2)/4.6, 0, 1);
      let exposure = EXP[id] ?? clamp(0.287 + 0.072*u + 0.011*gauss(r) + 0.006*field(x,y,4.1) + 0.008*bump(x,y,880,170,110) + 0.006*bump(x,y,90,260,140), 0.203, 0.467);
      let emp = clamp(0.748 + 0.065*bump(x,y,520,170,130) + 0.035*bump(x,y,880,150,90) - 0.07*bump(x,y,745,290,55) - 0.05*bump(x,y,640,420,120) - 0.06*bump(x,y,300,380,70) - 0.03*bump(x,y,90,230,80) + 0.025*u + 0.012*field(x,y,2.7) + 0.04*gauss(r), 0.142, 0.959);
      if (NO_EXP[id]) exposure = null;
      if (NO_EMP[id]) emp = null;
      const lg = s => Math.exp(s*gauss(r));
      const w = {
        fed: (id==='11001'?0.26:0.018)*lg(0.8), stg: 0.035*lg(0.6), locg: (0.09+0.07*(1-u))*lg(0.3),
        ag: (0.005+0.12*(1-u)**2*r())*lg(0.6), con: 0.06*lg(0.35), mfg: (0.06+0.06*bump(x,y,650,260,150))*lg(0.8),
        ttu: 0.19*lg(0.25), inf: (0.006+0.025*u)*lg(0.5), fin: (0.03+0.035*u)*lg(0.4), pbs: (0.05+0.11*u)*lg(0.4),
        edh: 0.145*lg(0.35), lh: 0.10*lg(0.45), oth: 0.03*lg(0.3), nd: 0.005+0.06*(1-u)*r()*r()
      };
      const sum = Object.values(w).reduce((a,b)=>a+b, 0);
      let jobsTarget = id==='06037' ? 4567586 : Math.max(0, Math.round(pop*(0.40+0.12*u+0.04*gauss(r))));
      const ind = {}; let total = 0;
      SECTORS.forEach(s => { ind[s.k] = Math.round(jobsTarget*w[s.k]/sum); total += ind[s.k]; });
      const hasInd = !NO_IND[id] && total > 0;
      let largest = null, uncertain = false;
      if (hasInd) {
        const cands = [['gov', ind.fed+ind.stg+ind.locg]].concat(PRIVATE.map(k=>[k, ind[k]])).sort((a,b)=>b[1]-a[1]);
        largest = cands[0][0];
        uncertain = ind.nd > (cands[0][1]-cands[1][1]);
      }
      const jobs = id==='06037' ? 4567586 : total;
      const base = f.properties.name;
      return {
        id, st, abbr, stName, name: displayName(base, id, abbr), pop, jobs,
        exposure, exposed: exposure==null ? null : Math.round(jobs*exposure), emp,
        llm: u > 0.42 ? base.replace(/ city$/i,'') + ', ' + abbr : 'Rural ' + stName,
        hasInd, ind: hasInd ? ind : null, total: hasInd ? total : 0, largest, uncertain
      };
    });
    const byId = {}, featById = {};
    counties.forEach(c => byId[c.id] = c);
    features.forEach(f => featById[String(f.id)] = f);
    features.forEach(f => f.id = String(f.id));
    const stateFeatById = {};
    topojson.feature(topo, topo.objects.states).features.forEach(f => stateFeatById[String(f.id)] = f);
    const states = Object.keys(ST).map(k => ({fips:k, abbr:ST[k][0], name:ST[k][1]})).sort((a,b)=>a.name.localeCompare(b.name));
    return {topo, features, counties, byId, featById, stateFeatById, states, sectors: SECTORS};
  }

  window.AIXData = {load};
})();
